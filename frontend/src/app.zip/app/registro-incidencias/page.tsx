'use client';

import PageContainer from '../(DashboardLayout)/components/container/PageContainer';
 
import Registros from '../(DashboardLayout)/components/registros/registros';

const proveedores= () => {
  return (
    <PageContainer title="Registros" description="Administración de Registros">
        
        <Registros></Registros>
        
    </PageContainer>
  );
};

export default proveedores;
