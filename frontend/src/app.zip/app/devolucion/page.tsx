'use client';

import React, { useEffect, useState } from 'react';
import { Box, Typography, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Button, Select, MenuItem } from '@mui/material';

const API_BASE_URL = 'http://localhost:3000/api';

const UserKeysTable: React.FC = () => {
  const [data, setData] = useState([]);
  const [selectedKey, setSelectedKey] = useState('');

  useEffect(() => {
    fetch(`${API_BASE_URL}/users`)
      .then((response) => response.json())
      .then((data) => setData(data))
      .catch((error) => console.error('Error al obtener los datos:', error));
  }, []);

  const handleDeleteKey = (idKey: string) => {
    fetch(`${API_BASE_URL}/delete-key`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ idKey }),
    })
      .then((response) => response.json())
      .then((result) => {
        console.log('Llave eliminada:', result);
        setData(data.filter((user: any) => user.Id_Key !== idKey));
      })
      .catch((error) => console.error('Error al eliminar la llave:', error));
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Usuarios con Llaves Asignadas
      </Typography>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Día</TableCell>
              <TableCell>Nombre</TableCell>
              <TableCell>Apellido</TableCell>
              <TableCell>DNI</TableCell>
              <TableCell>Llave (Id_Key)</TableCell>
              <TableCell>Acciones</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {data.map((user: any) => (
              <TableRow key={user.id}>
                <TableCell>{new Date(user.Permission_End).toLocaleDateString()}</TableCell>
                <TableCell>{user.Name}</TableCell>
                <TableCell>{user.Last_Name}</TableCell>
                <TableCell>{user.Dni}</TableCell>
                <TableCell>{user.Id_Key}</TableCell>
                <TableCell>
                  <Button 
                    variant="contained" 
                    color="error" 
                    onClick={() => handleDeleteKey(user.Id_Key)}
                  >
                    Eliminar Llave
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default UserKeysTable;
