'use client';

import React from 'react';
import { Box, Card, CardContent, Typography, Button, Grid, Container } from '@mui/material';

const API_BASE_URL = 'http://192.168.0.48/'; // Dirección IP del Arduino

const barriers = [
  { name: 'Barrera Tambo 1', endpoint: 'tambo1', disabled: false },
  { name: 'Barrera Tambo 2', endpoint: 'tambo2', disabled: true },
  { name: 'Portón Carmen', endpoint: 'carmen', disabled: true },
  { name: 'Lote 39', endpoint: 'lote39', disabled: true },
];

const BarriersControl: React.FC = () => {
  const handleBarrierAction = (endpoint: string, action: 'open' | 'closed') => {
    fetch(`${API_BASE_URL}${endpoint}/${action}`)
      .catch((error) => console.error(`Error al ${action === 'open' ? 'abrir' : 'cerrar'} la barrera ${endpoint}:`, error));
  };

  return (
    <Container>
      <Typography variant="h4" mb={4} align="center">
        Control de Barreras
      </Typography>
      <Grid container spacing={4} justifyContent="center">
        {barriers.map((barrier) => (
          <Grid item xs={12} sm={6} md={3} key={barrier.endpoint}>
            <Card>
              <CardContent>
                <Typography variant="h6" align="center">{barrier.name}</Typography>
                <Box display="flex" justifyContent="center" mt={2}>
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={() => handleBarrierAction(barrier.endpoint, 'open')}
                    disabled={barrier.disabled}
                  >
                    Abrir
                  </Button>
                  <Button
                    variant="contained"
                    color="error"
                    onClick={() => handleBarrierAction(barrier.endpoint, 'closed')}
                    style={{ marginLeft: '10px' }}
                    disabled={barrier.disabled}
                  >
                    Cerrar
                  </Button>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default BarriersControl;

