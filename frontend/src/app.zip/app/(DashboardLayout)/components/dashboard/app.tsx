'use client';
import React, { useEffect, useState } from 'react';
import { Box, Typography, Grid } from '@mui/material';
import QuickSummary from './QuickSummary';
import KeyStatusChart from './KeyStatusChart';
import RecentUsersTable from './RecentUsersTable';
import AccessHistory from './registros';
import BarriersControl from './barrieControl';


const Dashboard2: React.FC = () => {
  const [metrics, setMetrics] = useState({
    active_users: 0,
    total_providers: 0,
    active_keys: 0,
    inactive_keys: 0,
  });
  const [recentUsers, setRecentUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMetrics = async () => {
      try {
        const response = await fetch('http://localhost/adeco/api/get-dashboard-metrics.php');
        const data = await response.json();
        setMetrics(data);
      } catch (error) {
        console.error('Error fetching metrics:', error);
      }
    };

    const fetchRecentUsers = async () => {
      try {
        const response = await fetch('http://localhost/adeco/api/get-recent-users.php');
        const data = await response.json();
        setRecentUsers(data);
      } catch (error) {
        console.error('Error fetching recent users:', error);
      }
    };

    setLoading(true);
    Promise.all([fetchMetrics(), fetchRecentUsers()]).then(() => setLoading(false));
  }, []);

  const pieData = [
    { name: 'Activas', value: metrics.active_keys },
    { name: 'Inactivas', value: metrics.inactive_keys },
  ];

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" mb={3}>
        Panel de Control
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <QuickSummary metrics={metrics} />
        </Grid>
        <Grid item xs={12}>
          <BarriersControl />
        </Grid>
        <Grid item xs={12} md={4}>
          <KeyStatusChart data={pieData} />
        </Grid>
        <Grid item xs={12} md={6}>
          <RecentUsersTable users={recentUsers} loading={loading} />
        </Grid>
        <Grid item xs={12}>
          <AccessHistory />
        </Grid>
      </Grid>
    </Box>
  );
};

export default Dashboard2;
